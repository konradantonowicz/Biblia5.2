package pakiet.konrad.starfighter;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.IBinder;

@SuppressLint("Registered")
public class SFMusic extends Service {

    public static boolean isRunning = false;
    MediaPlayer player;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        setMusicOptions(this,SFEngine.LOOP_BACKGROUND_MUSIC,SFEngine.R_VOLUME,SFEngine.L_VOLUME,SFEngine.SPLASH_SCREEN_MUSIC);

    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        try {
            player.start();
            isRunning=true;

        }
        catch (Exception e)
        {
            isRunning=false;
            player.stop();
        }

        return super.onStartCommand(intent, flags, startId);



    }



    @Override
    public void onDestroy() {
        super.onDestroy();
        player.stop();
        player.release();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        player.stop();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }

    public void setMusicOptions(Context context, boolean isLooped, int rVolume,int lVolume, int soundFile)
    {
        player = MediaPlayer.create(context,soundFile);

        player.setLooping(isLooped);
        player.setVolume(rVolume,lVolume);

    }


}
