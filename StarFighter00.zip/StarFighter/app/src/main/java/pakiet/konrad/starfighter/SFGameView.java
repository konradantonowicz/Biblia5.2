package pakiet.konrad.starfighter;

import android.content.Context;
import android.opengl.GLSurfaceView;

public class SFGameView extends GLSurfaceView {
    public SFGameView(Context context) {
        super(context);
    }
}
